<title><?=$title?></title>
<div class="container-fluid margin-top-5">
	<div class="container">
		<div class="alert alert-info text-center"><h4><?=$message?></h4></div>
	</div>
</div>