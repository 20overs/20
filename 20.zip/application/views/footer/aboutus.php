<div class="container-fluid margin-top-5">
<div class="container">
	<span class="h3">About Us</span>

      <div id="" class="">       
        <p class="font-source h4">
         In the summer of 2012, there was a high adrenaline rushing cricket game being played between two college teams in Chennai, India. While watching that game, the founders of 20overs.com realized that, while there are plenty of websites that cover international and some domestic level cricket games, there is no website available to record college level and school level games. That's when the idea of 20overs.com was born.</p>
        <p class="single font-source h4">
        We are a team of programmers that are working frenetically to make it the best experience for people looking for local games. We are here to take local cricket to the next level.</P>
        <p class="single font-source h4">
        If you play cricket at school level or college level or even if you play 'street cricket', 20overs.com is for you. You can register your team, your team players, their profile, enter tournament information among other things. It doesn't stop there, you can market yourself as a bowler, batsman, all rounder, coach and so on, so that other teams that are looking for talent can hire you.</p>
        <p class="single font-source h4">
        If you are a cricket enthusiast, this site is for you. Here you'll find interesting information about local cricket. You can even start your own franchise with local lads with the information available about players and coaches available at 20overs.com.</p>
        <p class="single font-source h4">
        Please feel free to contact us with comments and suggestions.
        </p>        
	</div>
</div>
</div>