<footer class="page-footer indigo">
<br>
  <div class="row">
    <div class="container">
      <div class="col l2 m2 offset-l2">
        <a class="white-text text-lighten-3 collection-item" href="#!">CONTACT US</a>
      </div>
      <div class="col l2 m2">
        <a class="white-text text-lighten-3 collection-item" href="#!">ABOUT US</a>
      </div>
      <div class="col l2 m2">
        <a class="white-text text-lighten-3 collection-item" href="#!">PRIVACY POLICY </a>
      </div>
      <div class="col l2 m2">
        <a class="white-text text-lighten-3 collection-item" href="#!">OUR TEAM </a>
      </div>
      <div class="col l2 m2">
        <a class="white-text text-lighten-3 collection-item" href="#!">FAQ</a>
      </div>
    </div>
  </div>
  <center><span class="white-text">Copy Rights @ 2015 20overs.com -Powered by TEAM confidence. - All rights reserved.</span></center>
<br>
</footer>
</body>
</html>