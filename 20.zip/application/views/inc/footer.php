<div class="container-fluid">
	<div class="row new-footer">
		<ul class="no-style footer-ul">
		<li><a href="<?=site_url('welcome/contactform')?>">Contact Us</a></li>
		<li><a href="<?=site_url('welcome/aboutus')?>">About Us</a></li>
		<li><a href="<?=site_url('welcome/privacypolicy')?>">Privacy Policy</a></li>
		<li><a href="<?=site_url('welcome/ourteam')?>">Our Team</a></li>
		<li><a href="<?=site_url('welcome/faq')?>">FAQ</a></li>
		<p>Copy Rights @ <?=date('Y')?>  20overs.com -Powered by TEAM confidence. - All rights reserved.</p>		</ul>
	</div>
</div>
</body>
</html>




<script src="<?=site_url()?>public/js/bootstrap.min.js"></script>
<script src="<?=site_url()?>public/js/bootstrap-datepicker.js"></script>

<!--
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.0/js/bootstrap-datepicker.min.js"></script>
-->

<script type="text/javascript" src="<?=site_url()?>public/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?=site_url()?>public/js/additional.methods.js"></script>
<script src="<?=site_url()?>public/js/sweetalert.min.js"></script>
<script src="<?=site_url()?>public/js/main.js"></script>

<script type="text/javascript" src="<?=site_url()?>public/js/smoothscroll.js"></script>