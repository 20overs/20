<div class="continer-fluid margin-top-5">
	<div class="container">
		<div class="alert alert-<?=$alert?>">
			<div class="text-center">
				<p class="h2"><?=$message?></p>
			</div>
		</div>
	</div>
</div>