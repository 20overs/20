<html>
<head>
<title>Upload Form</title>
</head>
<body>

<h3>Your file was Error uploaded!</h3>

<ul>
<?php
	print_r($error);
?>
</body>
</html>