<?php

echo json_encode('[{"Team1Name":"Sri Lanka","Team2Name":"India"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"Bangladesh","Team2Name":"South Africa"},{"Team1Name":"England","Team2Name":"Australia"},{"Team1Name":"Sri Lanka","Team2Name":"India"}]');
?>