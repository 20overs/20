<?php
$con = mysqli_connect('localhost','root','','20overs');
//$con = mysqli_connect('localhost','vada1972','mouse1972','20overs');
?>